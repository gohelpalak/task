import React from 'react'

function Header() {
  return (
    <>
    <div className='header'>
        <div className="container" style={{textAlign:"center"}}>
            <h1>TODO LIST</h1>
        </div>
    </div>
    
    </>
  )
}

export default Header